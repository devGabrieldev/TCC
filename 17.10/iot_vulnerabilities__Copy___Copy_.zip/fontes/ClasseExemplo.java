/**
 * Classe de exemplo.
 * 
 * @author David Buzatto
 */
public class Grafo {
    
    public static void main( String[] args ) {
        
        System.out.println( "Exemplo de codigo fonte!" );
        System.out.println( "Nao use acentos!" );
        
    }
    
}
